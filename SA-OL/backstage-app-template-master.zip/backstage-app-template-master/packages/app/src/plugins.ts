export { plugin as WelcomePlugin } from 'plugin-welcome';
