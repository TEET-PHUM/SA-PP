module.exports = {
  extends: [require.resolve('@backstage/cli/config/eslint')],
};
