export { default } from './WelcomePage';
